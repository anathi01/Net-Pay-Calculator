grossPay = float(input("Enter your annual Gross Pay: "))
taxableIncome = float(0)
taxedAddons = float(0)

if (grossPay >= float(1817000)):
    taxableIncome = float(0.45)
    taxedAddons = float(644489)
    
    taxAmount = (taxedAddons + (taxableIncome * (grossPay - float(1817000)))) - float(17235)
    netPay = grossPay - taxAmount
    print("---Results---" + "\nGross Salary: R" + str("{:,}".format(int(grossPay))) + ".00" + "\nIncome Tax: R" + str("{:,}".format(round(taxAmount))) + ".00" + "\nNet Pay: R" +str("{:,}".format(int(netPay)))  + ".00")
elif (grossPay >= float(857901)):
    taxableIncome = float(0.41)
    taxedAddons = float(251258)
    
    taxAmount = (taxedAddons + (taxableIncome * (grossPay - float(857901)))) - float(17235)
    netPay = grossPay - taxAmount
    print("---Results---" + "\nGross Salary: R" + str("{:,}".format(int(grossPay))) + ".00" + "\nIncome Tax: R" + str("{:,}".format(round(taxAmount))) + ".00" + "\nNet Pay: R" +str("{:,}".format(int(netPay)))  + ".00")
elif (grossPay >= float(673001)):
    taxableIncome = float(0.39)
    taxedAddons = float(179147)
    
    taxAmount = (taxedAddons + (taxableIncome * (grossPay - float(673001)))) - float(17235)
    netPay = grossPay - taxAmount
    print("---Results---" + "\nGross Salary: R" + str("{:,}".format(int(grossPay))) + ".00" + "\nIncome Tax: R" + str("{:,}".format(round(taxAmount))) + ".00" + "\nNet Pay: R" +str("{:,}".format(int(netPay)))  + ".00")   
elif (grossPay >= float(512801)):
    taxableIncome = float(0.360)
    taxedAddons = float(121475)
    
    taxAmount = (taxedAddons + (taxableIncome * (grossPay - float(512801)))) - float(17235)
    netPay = grossPay - taxAmount
    print("---Results---" + "\nGross Salary: R" + str("{:,}".format(int(grossPay))) + ".00" + "\nIncome Tax: R" + str("{:,}".format(round(taxAmount))) + ".00" + "\nNet Pay: R" +str("{:,}".format(int(netPay)))  + ".00")
elif (grossPay >= float(370501)):
    taxableIncome = float(0.31)
    taxedAddons = float(77362)
    
    taxAmount = (taxedAddons + (taxableIncome * (grossPay - float(370501)))) - float(17235)
    netPay = grossPay - taxAmount
    print("---Results---" + "\nGross Salary: R" + str("{:,}".format(int(grossPay))) + ".00" + "\nIncome Tax: R" + str("{:,}".format(round(taxAmount))) + ".00" + "\nNet Pay: R" +str("{:,}".format(int(netPay)))  + ".00")
elif (grossPay >= float(237101)):
    taxableIncome = float(0.26)
    taxedAddons = float(42678)
    
    taxAmount = (taxedAddons + (taxableIncome * (grossPay - float(237101)))) - float(17235)
    netPay = grossPay - taxAmount
    print("---Results---" + "\nGross Salary: R" + str("{:,}".format(int(grossPay))) + ".00" + "\nIncome Tax: R" + str("{:,}".format(round(taxAmount))) + ".00" + "\nNet Pay: R" +str("{:,}".format(int(netPay)))  + ".00")
elif (grossPay >= float(1)):
    taxableIncome = float(0.18)
    taxedAddons = float(0)
    
    taxAmount = (taxedAddons + (taxableIncome * (grossPay - float(1)))) - float(17235)
    netPay = grossPay - taxAmount
    print("---Results---" + "\nGross Salary: R" + str("{:,}".format(int(grossPay))) + ".00" + "\nIncome Tax: R" + str("{:,}".format(round(taxAmount))) + ".00" + "\nNet Pay: R" +str("{:,}".format(int(netPay)))  + ".00")
